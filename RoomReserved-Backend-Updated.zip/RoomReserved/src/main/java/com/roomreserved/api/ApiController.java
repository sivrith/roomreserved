package com.roomreserved.api;

import com.roomreserved.model.AppUser;
import com.roomreserved.model.Booking;
import com.roomreserved.model.Room;
import com.roomreserved.payment.PayMongoCheckoutService;
import com.roomreserved.repo.BookingRepository;
import com.roomreserved.repo.RoomRepository;
import com.roomreserved.repo.UserRepository;
import com.roomreserved.service.BookingService;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@RestController
@RequestMapping("/api")
@Validated
public class ApiController {
    private final RoomRepository rooms;
    private final BookingRepository bookings;
    private final UserRepository users;
    private final BookingService bookingService;
    private final PasswordEncoder passwordEncoder;
    private final PayMongoCheckoutService payments;

    public ApiController(RoomRepository rooms, BookingRepository bookings, UserRepository users,
                         BookingService bookingService, PasswordEncoder passwordEncoder,
                         PayMongoCheckoutService payments) {
        this.rooms = rooms;
        this.bookings = bookings;
        this.users = users;
        this.bookingService = bookingService;
        this.passwordEncoder = passwordEncoder;
        this.payments = payments;
    }

    @GetMapping("/csrf")
    public Map<String, String> csrf(CsrfToken token) {
        return Map.of("token", token.getToken());
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "ok", "service", "RoomReserved API");
    }

    @GetMapping("/rooms")
    public List<RoomDto> listRooms() {
        return rooms.findByActiveTrue().stream().map(RoomDto::from).toList();
    }

    @GetMapping("/rooms/{id}")
    public ResponseEntity<?> getRoom(@PathVariable Long id) {
        return rooms.findById(id).filter(Room::isActive)
                .<ResponseEntity<?>>map(room -> ResponseEntity.ok(RoomDto.from(room)))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(Map.of("error", "Room not found.")));
    }

    @GetMapping("/availability")
    public ResponseEntity<?> availability(@RequestParam Long roomId,
                                          @RequestParam LocalDate checkIn,
                                          @RequestParam LocalDate checkOut,
                                          @RequestParam(defaultValue = "1") int quantity) {
        if (quantity < 1 || quantity > 10 || !checkIn.isAfter(LocalDate.now().minusDays(1))
                || !checkOut.isAfter(checkIn)) {
            return ResponseEntity.badRequest().body(Map.of("error", "Choose valid future dates and a room quantity from 1 to 10."));
        }
        Room room = rooms.findById(roomId).orElse(null);
        if (room == null || !room.isActive()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Room not found."));
        }
        long reserved = bookings.countConflicts(roomId, checkIn, checkOut);
        int remaining = (int) Math.max(0, room.getInventoryCount() - reserved);
        return ResponseEntity.ok(new AvailabilityDto(remaining >= quantity, room.getInventoryCount(),
                (int) reserved, remaining, quantity));
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@Valid @RequestBody RegisterRequest request) {
        String email = request.email().trim().toLowerCase(Locale.ROOT);
        if (users.findByEmail(email).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of("error", "An account with this email already exists."));
        }
        AppUser user = new AppUser();
        user.setFullName(request.fullName().trim());
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(request.password()));
        user.setRole("USER");
        users.save(user);
        return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                "message", "Account created. Please sign in.", "email", email));
    }

    @GetMapping("/me")
    public Map<String, String> me(Authentication authentication) {
        AppUser user = users.findByEmail(authentication.getName()).orElseThrow();
        return Map.of("email", user.getEmail(), "fullName", user.getFullName(), "role", user.getRole());
    }

    @GetMapping("/bookings")
    public List<BookingDto> myBookings(Authentication authentication) {
        return bookings.findByUserEmailOrderByCreatedAtDesc(authentication.getName())
                .stream().map(BookingDto::from).toList();
    }

    @PostMapping("/bookings")
    public ResponseEntity<?> createBooking(@Valid @RequestBody CreateBookingRequest request,
                                           Authentication authentication) {
        try {
            AppUser user = users.findByEmail(authentication.getName()).orElseThrow();
            Booking booking = bookingService.createHold(request.roomId(), request.checkIn(), request.checkOut(),
                    request.promoCode(), user, request.quantity(), request.adults(), request.children());
            return ResponseEntity.status(HttpStatus.CREATED).body(BookingDto.from(booking));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    @PostMapping("/bookings/{id}/checkout")
    public ResponseEntity<?> createCheckout(@PathVariable Long id, Authentication authentication) {
        try {
            String checkoutUrl = payments.createOrReuseCheckout(id, authentication.getName());
            return ResponseEntity.ok(Map.of("checkoutUrl", checkoutUrl,
                    "message", "Continue to the secure PayMongo checkout page to pay."));
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }

    @PostMapping("/bookings/{id}/cancel")
    @Transactional
    public ResponseEntity<?> cancelBooking(@PathVariable Long id, Authentication authentication) {
        Booking booking = bookings.findByIdForUpdate(id).orElse(null);
        if (booking == null) return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Booking not found."));
        if (!booking.getUser().getEmail().equals(authentication.getName())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", "You cannot cancel another guest's booking."));
        }
        if (!booking.getCheckIn().isAfter(LocalDate.now())
                || !List.of("PENDING", "CONFIRMED").contains(booking.getStatus())) {
            return ResponseEntity.badRequest().body(Map.of("error", "This booking can no longer be cancelled here."));
        }
        booking.setStatus("CANCELLED");
        return ResponseEntity.ok(BookingDto.from(bookings.save(booking)));
    }

    public record RegisterRequest(@NotBlank @Size(max = 120) String fullName,
                                  @NotBlank @Email @Size(max = 254) String email,
                                  @NotBlank @Size(min = 8, max = 72) String password) {}

    public record CreateBookingRequest(@NotNull Long roomId, @NotNull LocalDate checkIn,
                                       @NotNull LocalDate checkOut, @Size(max = 40) String promoCode,
                                       int quantity, int adults, int children) {
        public CreateBookingRequest {
            if (quantity == 0) quantity = 1;
            if (adults == 0) adults = 2;
        }
    }

    public record RoomDto(Long id, String name, String description, BigDecimal pricePerNight,
                          String imageUrl, String amenities, int capacity, int inventoryCount) {
        static RoomDto from(Room room) {
            return new RoomDto(room.getId(), room.getName(), room.getDescription(), room.getPricePerNight(),
                    room.getImageUrl(), room.getAmenities(), room.getCapacity(), room.getInventoryCount());
        }
    }

    public record AvailabilityDto(boolean available, int inventoryCount, int reservedQuantity,
                                  int remainingQuantity, int requestedQuantity) {}

    public record BookingDto(Long id, String bookingReference, Long roomId, String roomName,
                             LocalDate checkIn, LocalDate checkOut, int quantity, int adults, int children,
                             BigDecimal roomSubtotal, BigDecimal discountAmount, BigDecimal taxAmount,
                             BigDecimal serviceFee, BigDecimal totalPrice, String status,
                             String paymentStatus, String paymentCheckoutUrl, String promoCode,
                             java.time.LocalDateTime holdExpiresAt, java.time.LocalDateTime createdAt) {
        static BookingDto from(Booking booking) {
            return new BookingDto(booking.getId(), booking.getBookingReference(), booking.getRoom().getId(),
                    booking.getRoom().getName(), booking.getCheckIn(), booking.getCheckOut(), booking.getQuantity(),
                    booking.getAdults(), booking.getChildren(), booking.getRoomSubtotal(), booking.getDiscountAmount(),
                    booking.getTaxAmount(), booking.getServiceFee(), booking.getTotalPrice(), booking.getStatus(),
                    booking.getPaymentStatus(), booking.getPaymongoCheckoutUrl(), booking.getPromoCode(),
                    booking.getHoldExpiresAt(), booking.getCreatedAt());
        }
    }
}
