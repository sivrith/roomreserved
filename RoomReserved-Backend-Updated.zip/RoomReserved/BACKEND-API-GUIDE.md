# RoomReserved backend API

The Spring Boot backend uses Java 21, Spring Security, Spring Data JPA, and PostgreSQL. It is a separate service from the static `cloudflare-site/` frontend.

## Run locally

1. Install Java 21 and Docker Desktop (Docker Compose is included with current Docker Desktop releases).
2. Copy `.env.example` to `.env` and replace `DB_PASSWORD` with a long random value.
3. Run `docker compose up --build` from this folder.
4. Visit `http://localhost:8080/api/health`. Expected response: `{"status":"ok","service":"RoomReserved API"}`.

## Configure the frontend origin

Set `FRONTEND_ORIGIN` to the exact deployed frontend origin, including `https://` but without a trailing slash. For example, `https://your-project.pages.dev`. Do not use `*` when credentialed requests are enabled.

For a separate HTTPS frontend that must keep a signed-in session across origins, configure `SESSION_COOKIE_SAME_SITE=none` and `SESSION_COOKIE_SECURE=true`. Browsers may still restrict third-party cookies; a same-site custom domain or a same-origin reverse proxy is more reliable. Keep the database private.

## API routes

- `GET /api/health` — service health check.
- `GET /api/rooms` — active rooms, prices, capacity, and amenities.
- `GET /api/rooms/{id}` — one active room.
- `GET /api/availability?roomId=1&checkIn=2027-01-10&checkOut=2027-01-12&quantity=1` — inventory check.
- `POST /api/register` — create a guest account. JSON body: `{"fullName":"Guest Name","email":"guest@example.com","password":"at-least-8-characters"}`.
- `GET /api/csrf` — obtain a CSRF token before state-changing authenticated requests.
- `GET /api/me` — current signed-in account.
- `GET /api/bookings` — current account's bookings.
- `POST /api/bookings` — create a temporary booking hold. JSON body: `{"roomId":1,"checkIn":"2027-01-10","checkOut":"2027-01-12","quantity":1,"adults":2,"children":0,"promoCode":null}`.
- `POST /api/bookings/{id}/checkout` — create/reuse a secure PayMongo hosted-checkout session for the signed-in guest. Returns `checkoutUrl`; navigate to it to pay. Requires configured PayMongo test credentials and an active hold.
- `POST /api/bookings/{id}/cancel` — cancel an eligible booking owned by the signed-in guest.

Authenticated endpoints use the existing Spring Security session. Sign-in uses the Spring Security form login endpoint `/login` with form fields `username` (email) and `password`; it is not a JSON login endpoint. For API mutations, keep the session cookie and send the token from `/api/csrf` in the `X-XSRF-TOKEN` header. The CSRF exception on `/api/register` is intentional because registration is a public endpoint; all other state-changing endpoints retain CSRF protection.

## Payment safety

A booking created through the API is a temporary `PENDING` hold. It is not confirmed or paid. Only the verified PayMongo webhook can confirm payment. Set PayMongo secrets as environment variables on the backend host; never place them in frontend JavaScript or commit them to Git.

## Production warning

This is a backend foundation, not a declaration that the service is production-ready. Before accepting real bookings, configure a production database and credentials, run build and integration tests, verify the frontend integration and payment webhook end-to-end, add database migrations, review cancellation/refund rules, and set up monitoring and backups. Replace sample rooms and prices with verified property data.
